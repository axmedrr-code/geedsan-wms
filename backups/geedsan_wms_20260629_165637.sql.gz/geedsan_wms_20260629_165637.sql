--
-- PostgreSQL database dump
--

\restrict 4iYOjBzjMXbHtQQSfFfocvVUsfZhzNQMFvr7nPzPBxd8eqJrtsQ8lX4OoCDTvo9

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alarms; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.alarms (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    meter_id uuid,
    device_eui character varying(16) NOT NULL,
    alarm_type character varying(50) NOT NULL,
    severity character varying(20) DEFAULT 'warning'::character varying NOT NULL,
    message text,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    triggered_at timestamp with time zone DEFAULT now() NOT NULL,
    acknowledged_at timestamp with time zone,
    acknowledged_by uuid,
    resolved_at timestamp with time zone,
    resolved_by uuid,
    resolution_notes text,
    ai_analysis text,
    ai_recommendation text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT alarms_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT alarms_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'acknowledged'::character varying, 'resolved'::character varying])::text[])))
);


ALTER TABLE public.alarms OWNER TO geedsan;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    entity_type character varying(50),
    entity_id uuid,
    old_values jsonb,
    new_values jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_log OWNER TO geedsan;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: geedsan
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO geedsan;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geedsan
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: backup_log; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.backup_log (
    id bigint NOT NULL,
    database_name character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'success'::character varying NOT NULL,
    file_path text,
    file_size_bytes bigint,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT backup_log_status_check CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.backup_log OWNER TO geedsan;

--
-- Name: backup_log_id_seq; Type: SEQUENCE; Schema: public; Owner: geedsan
--

CREATE SEQUENCE public.backup_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_log_id_seq OWNER TO geedsan;

--
-- Name: backup_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geedsan
--

ALTER SEQUENCE public.backup_log_id_seq OWNED BY public.backup_log.id;


--
-- Name: base_cache_signaling; Type: SEQUENCE; Schema: public; Owner: geedsan
--

CREATE SEQUENCE public.base_cache_signaling
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.base_cache_signaling OWNER TO geedsan;

--
-- Name: base_registry_signaling; Type: SEQUENCE; Schema: public; Owner: geedsan
--

CREATE SEQUENCE public.base_registry_signaling
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.base_registry_signaling OWNER TO geedsan;

--
-- Name: billing_cycles; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.billing_cycles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    cycle_type character varying(20) DEFAULT 'monthly'::character varying,
    period_start date NOT NULL,
    period_end date NOT NULL,
    due_date date NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    invoice_id uuid,
    amount numeric(14,2) DEFAULT 0 NOT NULL,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT billing_cycles_cycle_type_check CHECK (((cycle_type)::text = ANY ((ARRAY['monthly'::character varying, 'quarterly'::character varying, 'annual'::character varying, 'custom'::character varying])::text[]))),
    CONSTRAINT billing_cycles_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'posted'::character varying, 'paid'::character varying, 'overdue'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.billing_cycles OWNER TO geedsan;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.customers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_number character varying(50) NOT NULL,
    full_name character varying(150) NOT NULL,
    email character varying(100),
    phone character varying(30),
    address text,
    city character varying(100),
    district character varying(100),
    tariff_type character varying(30) DEFAULT 'residential'::character varying,
    account_status character varying(20) DEFAULT 'active'::character varying,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    odoo_id character varying(100),
    CONSTRAINT customers_account_status_check CHECK (((account_status)::text = ANY ((ARRAY['active'::character varying, 'suspended'::character varying, 'terminated'::character varying])::text[]))),
    CONSTRAINT customers_tariff_type_check CHECK (((tariff_type)::text = ANY ((ARRAY['residential'::character varying, 'commercial'::character varying, 'industrial'::character varying, 'government'::character varying])::text[])))
);


ALTER TABLE public.customers OWNER TO geedsan;

--
-- Name: meters; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.meters (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    device_eui character varying(16) NOT NULL,
    meter_number character varying(50) NOT NULL,
    customer_id uuid,
    application_id character varying(100),
    status character varying(20) DEFAULT 'active'::character varying,
    is_online boolean DEFAULT false,
    valve_status character varying(20) DEFAULT 'unknown'::character varying,
    total_consumption numeric(12,3) DEFAULT 0,
    current_flow numeric(8,3) DEFAULT 0,
    battery_voltage numeric(4,2),
    rssi integer,
    snr numeric(6,2),
    latitude numeric(10,7),
    longitude numeric(10,7),
    installation_address text,
    firmware_version character varying(20),
    installed_at timestamp with time zone,
    last_seen timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    pressure numeric(6,2),
    pulse_count bigint,
    pulse_constant_liters numeric(8,2) DEFAULT 100,
    meter_serial character varying(20),
    status_word_1 integer,
    status_word_2 integer,
    trigger_source integer,
    CONSTRAINT meters_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'faulty'::character varying, 'removed'::character varying])::text[]))),
    CONSTRAINT meters_valve_status_check CHECK (((valve_status)::text = ANY ((ARRAY['open'::character varying, 'closed'::character varying, 'unknown'::character varying, 'fault'::character varying])::text[])))
);


ALTER TABLE public.meters OWNER TO geedsan;

--
-- Name: dashboard_stats; Type: VIEW; Schema: public; Owner: geedsan
--

CREATE VIEW public.dashboard_stats AS
 SELECT ( SELECT count(*) AS count
           FROM public.meters
          WHERE ((meters.status)::text = 'active'::text)) AS total_meters,
    ( SELECT count(*) AS count
           FROM public.meters
          WHERE ((meters.is_online = true) AND ((meters.status)::text = 'active'::text))) AS online_meters,
    ( SELECT count(*) AS count
           FROM public.meters
          WHERE ((meters.is_online = false) AND ((meters.status)::text = 'active'::text))) AS offline_meters,
    ( SELECT COALESCE(sum(meters.total_consumption), (0)::numeric) AS "coalesce"
           FROM public.meters
          WHERE ((meters.status)::text = 'active'::text)) AS total_consumption,
    ( SELECT count(*) AS count
           FROM public.alarms
          WHERE ((alarms.status)::text = 'active'::text)) AS active_alarms,
    ( SELECT count(*) AS count
           FROM public.alarms
          WHERE (((alarms.status)::text = 'active'::text) AND ((alarms.severity)::text = 'critical'::text))) AS critical_alarms,
    ( SELECT count(*) AS count
           FROM public.customers
          WHERE ((customers.account_status)::text = 'active'::text)) AS total_customers;


ALTER VIEW public.dashboard_stats OWNER TO geedsan;

--
-- Name: downlink_commands; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.downlink_commands (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    meter_id uuid,
    device_eui character varying(16) NOT NULL,
    command_type character varying(50) NOT NULL,
    command_hex character varying(20),
    command_base64 text,
    f_port integer DEFAULT 5,
    status character varying(20) DEFAULT 'pending'::character varying,
    chirpstack_id character varying(100),
    error_message text,
    sent_by uuid,
    sent_at timestamp with time zone,
    confirmed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    retry_count integer DEFAULT 0,
    next_retry_at timestamp with time zone,
    CONSTRAINT downlink_commands_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'sent'::character varying, 'confirmed'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.downlink_commands OWNER TO geedsan;

--
-- Name: gateways; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.gateways (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    gateway_eui character varying(16) NOT NULL,
    name character varying(100),
    description text,
    latitude numeric(10,7),
    longitude numeric(10,7),
    is_online boolean DEFAULT false,
    last_seen timestamp with time zone,
    last_rssi integer,
    last_snr numeric(6,2),
    uplink_count bigint DEFAULT 0,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT gateways_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'maintenance'::character varying])::text[])))
);


ALTER TABLE public.gateways OWNER TO geedsan;

--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.invoice_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    invoice_id uuid NOT NULL,
    description text NOT NULL,
    quantity numeric(10,2) DEFAULT 1 NOT NULL,
    unit_price numeric(12,2) DEFAULT 0 NOT NULL,
    line_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.invoice_items OWNER TO geedsan;

--
-- Name: invoice_payments; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.invoice_payments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    invoice_id uuid NOT NULL,
    amount numeric(14,2) NOT NULL,
    payment_date timestamp with time zone DEFAULT now() NOT NULL,
    method character varying(50) DEFAULT 'cash'::character varying,
    reference character varying(100),
    note text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    odoo_id character varying(100)
);


ALTER TABLE public.invoice_payments OWNER TO geedsan;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.invoices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    invoice_number character varying(80) NOT NULL,
    issue_date date NOT NULL,
    due_date date NOT NULL,
    tariff_type character varying(30) DEFAULT 'residential'::character varying,
    total_amount numeric(14,2) DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    odoo_id character varying(100),
    CONSTRAINT invoices_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'paid'::character varying, 'overdue'::character varying, 'cancelled'::character varying])::text[]))),
    CONSTRAINT invoices_tariff_type_check CHECK (((tariff_type)::text = ANY ((ARRAY['residential'::character varying, 'commercial'::character varying, 'industrial'::character varying, 'government'::character varying])::text[])))
);


ALTER TABLE public.invoices OWNER TO geedsan;

--
-- Name: meter_flow_history; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.meter_flow_history (
    id bigint NOT NULL,
    meter_id uuid NOT NULL,
    device_eui character varying(16) NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    interval_minutes integer NOT NULL,
    consumption_pulses bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.meter_flow_history OWNER TO geedsan;

--
-- Name: meter_flow_history_id_seq; Type: SEQUENCE; Schema: public; Owner: geedsan
--

CREATE SEQUENCE public.meter_flow_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.meter_flow_history_id_seq OWNER TO geedsan;

--
-- Name: meter_flow_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geedsan
--

ALTER SEQUENCE public.meter_flow_history_id_seq OWNED BY public.meter_flow_history.id;


--
-- Name: meter_readings; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.meter_readings (
    id bigint NOT NULL,
    meter_id uuid NOT NULL,
    device_eui character varying(16) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    total_consumption numeric(12,3),
    current_flow numeric(8,3),
    battery_voltage numeric(4,2),
    rssi integer,
    snr numeric(6,2),
    f_port integer,
    f_cnt integer,
    raw_payload text,
    alarm_flags jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    pressure numeric(6,2),
    pulse_count bigint,
    status_word_1 integer,
    status_word_2 integer,
    trigger_source integer,
    gateway_eui character varying(16)
);


ALTER TABLE public.meter_readings OWNER TO geedsan;

--
-- Name: meter_readings_id_seq; Type: SEQUENCE; Schema: public; Owner: geedsan
--

CREATE SEQUENCE public.meter_readings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.meter_readings_id_seq OWNER TO geedsan;

--
-- Name: meter_readings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geedsan
--

ALTER SEQUENCE public.meter_readings_id_seq OWNED BY public.meter_readings.id;


--
-- Name: meter_summary; Type: VIEW; Schema: public; Owner: geedsan
--

CREATE VIEW public.meter_summary AS
 SELECT m.id,
    m.device_eui,
    m.meter_number,
    m.customer_id,
    m.application_id,
    m.status,
    m.is_online,
    m.valve_status,
    m.total_consumption,
    m.current_flow,
    m.battery_voltage,
    m.rssi,
    m.snr,
    m.latitude,
    m.longitude,
    m.installation_address,
    m.firmware_version,
    m.installed_at,
    m.last_seen,
    m.notes,
    m.created_at,
    m.updated_at,
    m.pressure,
    c.full_name AS customer_name,
    c.customer_number,
    c.phone AS customer_phone,
    c.tariff_type,
    ( SELECT count(*) AS count
           FROM public.alarms a
          WHERE ((a.meter_id = m.id) AND ((a.status)::text = 'active'::text))) AS active_alarms,
    ( SELECT count(*) AS count
           FROM public.alarms a
          WHERE ((a.meter_id = m.id) AND ((a.severity)::text = 'critical'::text) AND ((a.status)::text = 'active'::text))) AS critical_alarms,
    ( SELECT mr."timestamp"
           FROM public.meter_readings mr
          WHERE (mr.meter_id = m.id)
          ORDER BY mr."timestamp" DESC
         LIMIT 1) AS last_reading_time
   FROM (public.meters m
     LEFT JOIN public.customers c ON ((m.customer_id = c.id)));


ALTER VIEW public.meter_summary OWNER TO geedsan;

--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.notification_settings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    channel character varying(20) NOT NULL,
    recipient character varying(200),
    enabled_alarms jsonb DEFAULT '[]'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT notification_settings_channel_check CHECK (((channel)::text = ANY ((ARRAY['email'::character varying, 'telegram'::character varying, 'whatsapp'::character varying])::text[])))
);


ALTER TABLE public.notification_settings OWNER TO geedsan;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.notifications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    alarm_id uuid,
    channel character varying(20) NOT NULL,
    recipient character varying(200) NOT NULL,
    subject character varying(255),
    message text,
    status character varying(20) DEFAULT 'pending'::character varying,
    sent_at timestamp with time zone,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT notifications_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'sent'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.notifications OWNER TO geedsan;

--
-- Name: odoo_sync_queue; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.odoo_sync_queue (
    id bigint NOT NULL,
    entity_type character varying(20) NOT NULL,
    entity_id uuid NOT NULL,
    payload jsonb,
    status character varying(20) DEFAULT 'pending'::character varying,
    attempts integer DEFAULT 0,
    last_error text,
    next_attempt_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT odoo_sync_queue_entity_type_check CHECK (((entity_type)::text = ANY ((ARRAY['customer'::character varying, 'product'::character varying, 'invoice'::character varying])::text[]))),
    CONSTRAINT odoo_sync_queue_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'retry'::character varying, 'failed'::character varying, 'completed'::character varying])::text[])))
);


ALTER TABLE public.odoo_sync_queue OWNER TO geedsan;

--
-- Name: odoo_sync_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: geedsan
--

CREATE SEQUENCE public.odoo_sync_queue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.odoo_sync_queue_id_seq OWNER TO geedsan;

--
-- Name: odoo_sync_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geedsan
--

ALTER SEQUENCE public.odoo_sync_queue_id_seq OWNED BY public.odoo_sync_queue.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.products (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_code character varying(80) NOT NULL,
    name character varying(150) NOT NULL,
    description text,
    unit character varying(20) DEFAULT 'unit'::character varying,
    unit_price numeric(14,2) DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    odoo_id character varying(100),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT products_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying])::text[])))
);


ALTER TABLE public.products OWNER TO geedsan;

--
-- Name: reports; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.reports (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    report_type character varying(50) NOT NULL,
    title character varying(200) NOT NULL,
    period_start date,
    period_end date,
    parameters jsonb DEFAULT '{}'::jsonb,
    status character varying(20) DEFAULT 'pending'::character varying,
    file_path character varying(255),
    file_type character varying(10),
    file_size bigint,
    generated_by uuid,
    generated_at timestamp with time zone,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT reports_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'completed'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.reports OWNER TO geedsan;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.schema_migrations (
    id integer NOT NULL,
    filename character varying(255) NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO geedsan;

--
-- Name: schema_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: geedsan
--

CREATE SEQUENCE public.schema_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schema_migrations_id_seq OWNER TO geedsan;

--
-- Name: schema_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geedsan
--

ALTER SEQUENCE public.schema_migrations_id_seq OWNED BY public.schema_migrations.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.system_settings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key character varying(100) NOT NULL,
    value text,
    description text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_settings OWNER TO geedsan;

--
-- Name: tanker_deliveries; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.tanker_deliveries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    vehicle_number character varying(50) NOT NULL,
    driver_name character varying(100) NOT NULL,
    scheduled_at timestamp with time zone NOT NULL,
    delivery_volume numeric(12,3) NOT NULL,
    delivery_address text,
    status character varying(20) DEFAULT 'scheduled'::character varying,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tanker_deliveries_status_check CHECK (((status)::text = ANY ((ARRAY['scheduled'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.tanker_deliveries OWNER TO geedsan;

--
-- Name: users; Type: TABLE; Schema: public; Owner: geedsan
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(100) NOT NULL,
    role character varying(20) DEFAULT 'viewer'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_login timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'operator'::character varying, 'viewer'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO geedsan;

--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: backup_log id; Type: DEFAULT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.backup_log ALTER COLUMN id SET DEFAULT nextval('public.backup_log_id_seq'::regclass);


--
-- Name: meter_flow_history id; Type: DEFAULT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.meter_flow_history ALTER COLUMN id SET DEFAULT nextval('public.meter_flow_history_id_seq'::regclass);


--
-- Name: meter_readings id; Type: DEFAULT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.meter_readings ALTER COLUMN id SET DEFAULT nextval('public.meter_readings_id_seq'::regclass);


--
-- Name: odoo_sync_queue id; Type: DEFAULT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.odoo_sync_queue ALTER COLUMN id SET DEFAULT nextval('public.odoo_sync_queue_id_seq'::regclass);


--
-- Name: schema_migrations id; Type: DEFAULT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.schema_migrations ALTER COLUMN id SET DEFAULT nextval('public.schema_migrations_id_seq'::regclass);


--
-- Data for Name: alarms; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.alarms (id, meter_id, device_eui, alarm_type, severity, message, status, triggered_at, acknowledged_at, acknowledged_by, resolved_at, resolved_by, resolution_notes, ai_analysis, ai_recommendation, created_at) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.audit_log (id, user_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: backup_log; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.backup_log (id, database_name, status, file_path, file_size_bytes, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: billing_cycles; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.billing_cycles (id, customer_id, cycle_type, period_start, period_end, due_date, status, invoice_id, amount, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.customers (id, customer_number, full_name, email, phone, address, city, district, tariff_type, account_status, notes, created_at, updated_at, odoo_id) FROM stdin;
74ba6397-ff64-4007-b7f2-8be262fb0443		Ahmed Ali	ahmed@nuwaco.com	+252907727216		Garowe Somalia		residential	active	\N	2026-06-28 11:39:54.144473+00	2026-06-28 11:39:54.144473+00	\N
\.


--
-- Data for Name: downlink_commands; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.downlink_commands (id, meter_id, device_eui, command_type, command_hex, command_base64, f_port, status, chirpstack_id, error_message, sent_by, sent_at, confirmed_at, created_at, retry_count, next_retry_at) FROM stdin;
dee07c19-bc75-4aba-8697-ca67ec8a7cc2	d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	open_valve	261F0045	Jh8ARQ==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-28 13:31:41.719557+00	\N	2026-06-28 13:31:41.719557+00	3	\N
c2486a10-37b0-4afa-884e-0a945d89209c	d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	open_valve	261F0045	Jh8ARQ==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-28 13:33:40.027106+00	\N	2026-06-28 13:33:40.027106+00	3	\N
ee8d6921-c2d7-47a2-bb59-1174f2764a03	\N	TESTEUI00000001	open_valve	261F0045	Jh8ARQ==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-27 17:50:09.180646+00	\N	2026-06-27 17:50:09.180646+00	3	\N
412e498b-3a90-4b3d-998d-72cb7d817206	d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	open_valve	261F0045	Jh8ARQ==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-28 13:35:54.643858+00	\N	2026-06-28 13:35:54.643858+00	3	\N
806453d1-058c-4685-b4c4-f7bb8d27a0c9	d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	open_valve	261F0045	Jh8ARQ==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-28 13:36:31.738809+00	\N	2026-06-28 13:36:31.738809+00	3	\N
d4335693-9275-4507-bfe8-eb8e58e0286e	d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	close_valve	261F0146	Jh8BRg==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-29 10:08:09.744965+00	\N	2026-06-29 10:08:09.744965+00	3	\N
5b2b31a1-3b8b-4689-8bd8-e3495fa72fce	d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	open_valve	261F0045	Jh8ARQ==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-29 10:08:11.113097+00	\N	2026-06-29 10:08:11.113097+00	3	\N
db63d101-e7c8-44b2-a052-b13e779abd8d	d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	open_valve	261F0045	Jh8ARQ==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-28 14:03:22.525826+00	\N	2026-06-28 14:03:22.525826+00	3	\N
3aa073b4-898d-4564-b949-05ae31a4cfd1	d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	open_valve	261F0045	Jh8ARQ==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-29 10:33:09.174532+00	\N	2026-06-29 10:33:09.174532+00	3	\N
9a03b0f3-9f0a-401b-b27c-6929a947b906	d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	open_valve	261F0045	Jh8ARQ==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-29 05:37:22.885622+00	\N	2026-06-29 05:37:22.885622+00	3	\N
9826ec44-447d-4de7-8a9c-561fecd965da	\N	DIAGTEST00000001	config_report_interval	262500000E1069	JiUAAA4QaQ==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-29 13:50:20.823347+00	\N	2026-06-29 13:50:20.823347+00	0	2026-06-29 13:55:20.828+00
54698221-c155-4e9b-a778-0ce2a9e2fcfa	d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	open_valve	261F0045	Jh8ARQ==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-29 07:12:41.556341+00	\N	2026-06-29 07:12:41.556341+00	3	\N
e436abb3-ba27-468f-93dc-74cb60ff6f5a	d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	close_valve	261F0146	Jh8BRg==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-28 13:23:22.796586+00	\N	2026-06-28 13:23:22.796586+00	3	\N
f2117b30-abc9-4fd0-8923-e34755e46782	d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	open_valve	261F0045	Jh8ARQ==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-28 13:23:26.266485+00	\N	2026-06-28 13:23:26.266485+00	3	\N
49234dff-ee7c-417d-911c-fdb60ebd8d28	d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	dredge_valve	261F0247	Jh8CRw==	5	failed	\N	ChirpStack API key not configured	104f1d01-bd7e-44e9-bd25-55ddfd64f06f	2026-06-28 13:23:28.677619+00	\N	2026-06-28 13:23:28.677619+00	3	\N
\.


--
-- Data for Name: gateways; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.gateways (id, gateway_eui, name, description, latitude, longitude, is_online, last_seen, last_rssi, last_snr, uplink_count, status, created_at, updated_at) FROM stdin;
7d8c97b0-520c-485a-9a52-4bc5a35d7908	SIMGATEWAY00001A	\N	\N	\N	\N	t	2026-06-29 13:50:20.581687+00	-75	7.50	1	active	2026-06-29 13:50:20.581687+00	2026-06-29 13:50:20.581687+00
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.invoice_items (id, invoice_id, description, quantity, unit_price, line_order) FROM stdin;
\.


--
-- Data for Name: invoice_payments; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.invoice_payments (id, invoice_id, amount, payment_date, method, reference, note, created_by, created_at, odoo_id) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.invoices (id, customer_id, invoice_number, issue_date, due_date, tariff_type, total_amount, status, notes, created_by, created_at, updated_at, odoo_id) FROM stdin;
\.


--
-- Data for Name: meter_flow_history; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.meter_flow_history (id, meter_id, device_eui, recorded_at, interval_minutes, consumption_pulses, created_at) FROM stdin;
\.


--
-- Data for Name: meter_readings; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.meter_readings (id, meter_id, device_eui, "timestamp", total_consumption, current_flow, battery_voltage, rssi, snr, f_port, f_cnt, raw_payload, alarm_flags, created_at, pressure, pulse_count, status_word_1, status_word_2, trigger_source, gateway_eui) FROM stdin;
\.


--
-- Data for Name: meters; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.meters (id, device_eui, meter_number, customer_id, application_id, status, is_online, valve_status, total_consumption, current_flow, battery_voltage, rssi, snr, latitude, longitude, installation_address, firmware_version, installed_at, last_seen, notes, created_at, updated_at, pressure, pulse_count, pulse_constant_liters, meter_serial, status_word_1, status_word_2, trigger_source) FROM stdin;
d16dee21-eac7-4f69-8b8e-a04e0da805b6	70B3D57ED0051234	NUW-001	74ba6397-ff64-4007-b7f2-8be262fb0443	app001	active	f	unknown	0.000	0.000	\N	\N	\N	8.4060000	48.4820000	Garowe Puntland	v1	2026-06-28 11:44:47.90298+00	\N	test meter	2026-06-28 11:44:47.90298+00	2026-06-28 11:44:47.90298+00	\N	\N	100.00	\N	\N	\N	\N
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.notification_settings (id, user_id, channel, recipient, enabled_alarms, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.notifications (id, alarm_id, channel, recipient, subject, message, status, sent_at, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: odoo_sync_queue; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.odoo_sync_queue (id, entity_type, entity_id, payload, status, attempts, last_error, next_attempt_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.products (id, product_code, name, description, unit, unit_price, status, odoo_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.reports (id, report_type, title, period_start, period_end, parameters, status, file_path, file_type, file_size, generated_by, generated_at, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.schema_migrations (id, filename, applied_at) FROM stdin;
1	001_create_odoo_sync_queue.sql	2026-06-27 17:45:13.795188+00
2	002_meter_telemetry_enhancements.sql	2026-06-27 17:45:13.845725+00
3	003_downlink_retry.sql	2026-06-27 17:45:13.853384+00
4	000_baseline_schema.sql	2026-06-27 18:17:08.682614+00
5	004_odoo_sync_columns.sql	2026-06-28 10:45:56.371316+00
6	005_shengda_protocol_fields.sql	2026-06-28 10:45:56.395414+00
7	006_gateways.sql	2026-06-29 13:06:35.0289+00
8	007_backup_log.sql	2026-06-29 13:48:55.85215+00
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.system_settings (id, key, value, description, updated_at) FROM stdin;
12832866-5b37-49f5-b5be-ae7f9386a526	chirpstack_url	\N	ChirpStack server URL	2026-06-26 16:30:27.67162+00
ac5dc5cf-3665-41b2-8f2a-8339c065d63b	chirpstack_api_key	\N	ChirpStack API key	2026-06-26 16:30:27.67162+00
c5c70cbc-b6c4-4b2c-a657-d255ce1994f5	chirpstack_tenant_id	\N	ChirpStack tenant ID	2026-06-26 16:30:27.67162+00
67032b52-40be-4744-b466-a3da8a5305b2	email_smtp_host	\N	SMTP server hostname	2026-06-26 16:30:27.67162+00
94aa052b-de8d-4a05-a1cc-83d016206848	email_smtp_port	\N	SMTP server port	2026-06-26 16:30:27.67162+00
b1802d42-1e91-45e6-b6fd-1e376f005096	email_username	\N	SMTP auth username	2026-06-26 16:30:27.67162+00
811fb281-bc08-47ac-b120-1a3f7f133792	email_password	\N	SMTP auth password	2026-06-26 16:30:27.67162+00
488bb1db-a993-4a21-bd9d-3c8e757aa3c1	telegram_bot_token	\N	Telegram bot token	2026-06-26 16:30:27.67162+00
2cd7b444-f596-49a5-8a05-2465b61390a3	whatsapp_api_url	\N	WhatsApp API endpoint	2026-06-26 16:30:27.67162+00
f720de44-4e54-4da5-893e-b528c1d9a331	whatsapp_api_key	\N	WhatsApp API key	2026-06-26 16:30:27.67162+00
652e7089-bcf9-49de-b303-2c8e06fa3a67	anthropic_api_key	\N	Anthropic Claude API key	2026-06-26 16:30:27.67162+00
b1f93f84-913e-448d-8e04-9fb83080471f	low_battery_threshold	3.2	Low battery voltage threshold (V)	2026-06-26 16:30:27.67162+00
3b161027-2ccf-4292-bc87-8c3ff45b5514	leak_detection_threshold	5	Leak detection flow threshold (L/h)	2026-06-26 16:30:27.67162+00
94de8681-2351-4b42-b341-87fe2fbe7f3f	consumption_alert_multiplier	3	High consumption alert multiplier	2026-06-26 16:30:27.67162+00
901ed3c4-cf84-4679-8819-a69a6bac5013	backend_last_started_at	2026-06-29T13:48:55.956Z	Last backend process start time	2026-06-29 13:48:55.958555+00
\.


--
-- Data for Name: tanker_deliveries; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.tanker_deliveries (id, customer_id, vehicle_number, driver_name, scheduled_at, delivery_volume, delivery_address, status, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: geedsan
--

COPY public.users (id, username, email, password_hash, full_name, role, is_active, last_login, created_at, updated_at) FROM stdin;
104f1d01-bd7e-44e9-bd25-55ddfd64f06f	admin	admin@geedsan.com	$2a$12$UMubID4k0qNwDmEtl.akbOBjq.VoxGUzMEiZccHMtds9anqZoJVIO	System Administrator	admin	t	2026-06-29 13:50:39.422811+00	2026-06-26 16:30:27.666479+00	2026-06-26 16:30:27.666479+00
adc8be7c-81a0-43b6-be5d-94409a591eab	operator1	operator@geedsan.com	$2a$12$S7yAjbQJEzftOBeDKWkmHuFPbFhutDj0BCoxf355xJbgC5MtIRSzy	Field Operator	operator	t	2026-06-27 17:07:53.884335+00	2026-06-26 16:30:27.666479+00	2026-06-26 16:30:27.666479+00
32b74ba6-5b49-4293-90eb-e4c949dbeffd	viewer1	viewer@geedsan.com	$2a$12$Sy4n/DNf6Od7yOIfZ8bo1ecQipoFZjnbkso4DoW9z1wXdnPgoEEce	Report Viewer	viewer	t	2026-06-27 17:07:54.228633+00	2026-06-26 16:30:27.666479+00	2026-06-26 16:30:27.666479+00
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geedsan
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: backup_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geedsan
--

SELECT pg_catalog.setval('public.backup_log_id_seq', 1, false);


--
-- Name: base_cache_signaling; Type: SEQUENCE SET; Schema: public; Owner: geedsan
--

SELECT pg_catalog.setval('public.base_cache_signaling', 1, true);


--
-- Name: base_registry_signaling; Type: SEQUENCE SET; Schema: public; Owner: geedsan
--

SELECT pg_catalog.setval('public.base_registry_signaling', 1, true);


--
-- Name: meter_flow_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geedsan
--

SELECT pg_catalog.setval('public.meter_flow_history_id_seq', 6, true);


--
-- Name: meter_readings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geedsan
--

SELECT pg_catalog.setval('public.meter_readings_id_seq', 10, true);


--
-- Name: odoo_sync_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geedsan
--

SELECT pg_catalog.setval('public.odoo_sync_queue_id_seq', 1, false);


--
-- Name: schema_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geedsan
--

SELECT pg_catalog.setval('public.schema_migrations_id_seq', 8, true);


--
-- Name: alarms alarms_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.alarms
    ADD CONSTRAINT alarms_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: backup_log backup_log_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.backup_log
    ADD CONSTRAINT backup_log_pkey PRIMARY KEY (id);


--
-- Name: billing_cycles billing_cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.billing_cycles
    ADD CONSTRAINT billing_cycles_pkey PRIMARY KEY (id);


--
-- Name: customers customers_customer_number_key; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_customer_number_key UNIQUE (customer_number);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: downlink_commands downlink_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.downlink_commands
    ADD CONSTRAINT downlink_commands_pkey PRIMARY KEY (id);


--
-- Name: gateways gateways_gateway_eui_key; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.gateways
    ADD CONSTRAINT gateways_gateway_eui_key UNIQUE (gateway_eui);


--
-- Name: gateways gateways_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.gateways
    ADD CONSTRAINT gateways_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoice_payments invoice_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: meter_flow_history meter_flow_history_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.meter_flow_history
    ADD CONSTRAINT meter_flow_history_pkey PRIMARY KEY (id);


--
-- Name: meter_readings meter_readings_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.meter_readings
    ADD CONSTRAINT meter_readings_pkey PRIMARY KEY (id);


--
-- Name: meters meters_device_eui_key; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.meters
    ADD CONSTRAINT meters_device_eui_key UNIQUE (device_eui);


--
-- Name: meters meters_meter_number_key; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.meters
    ADD CONSTRAINT meters_meter_number_key UNIQUE (meter_number);


--
-- Name: meters meters_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.meters
    ADD CONSTRAINT meters_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_user_id_channel_key; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_user_id_channel_key UNIQUE (user_id, channel);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: odoo_sync_queue odoo_sync_queue_entity_type_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.odoo_sync_queue
    ADD CONSTRAINT odoo_sync_queue_entity_type_entity_id_key UNIQUE (entity_type, entity_id);


--
-- Name: odoo_sync_queue odoo_sync_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.odoo_sync_queue
    ADD CONSTRAINT odoo_sync_queue_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_product_code_key; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_product_code_key UNIQUE (product_code);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_filename_key; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_filename_key UNIQUE (filename);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_key_key; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_key_key UNIQUE (key);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: tanker_deliveries tanker_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.tanker_deliveries
    ADD CONSTRAINT tanker_deliveries_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_alarms_meter; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_alarms_meter ON public.alarms USING btree (meter_id);


--
-- Name: idx_alarms_severity; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_alarms_severity ON public.alarms USING btree (severity);


--
-- Name: idx_alarms_status; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_alarms_status ON public.alarms USING btree (status);


--
-- Name: idx_alarms_triggered; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_alarms_triggered ON public.alarms USING btree (triggered_at DESC);


--
-- Name: idx_backup_log_db_time; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_backup_log_db_time ON public.backup_log USING btree (database_name, created_at DESC);


--
-- Name: idx_billing_cycles_customer; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_billing_cycles_customer ON public.billing_cycles USING btree (customer_id);


--
-- Name: idx_billing_cycles_status; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_billing_cycles_status ON public.billing_cycles USING btree (status);


--
-- Name: idx_commands_meter; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_commands_meter ON public.downlink_commands USING btree (meter_id);


--
-- Name: idx_commands_sent; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_commands_sent ON public.downlink_commands USING btree (sent_at DESC);


--
-- Name: idx_flow_history_meter_time; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_flow_history_meter_time ON public.meter_flow_history USING btree (meter_id, recorded_at DESC);


--
-- Name: idx_gateways_eui; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_gateways_eui ON public.gateways USING btree (gateway_eui);


--
-- Name: idx_gateways_online; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_gateways_online ON public.gateways USING btree (is_online);


--
-- Name: idx_invoice_payments_invoice; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_invoice_payments_invoice ON public.invoice_payments USING btree (invoice_id);


--
-- Name: idx_invoices_customer; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_invoices_customer ON public.invoices USING btree (customer_id);


--
-- Name: idx_invoices_due_date; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_invoices_due_date ON public.invoices USING btree (due_date);


--
-- Name: idx_invoices_status; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_invoices_status ON public.invoices USING btree (status);


--
-- Name: idx_meters_customer; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_meters_customer ON public.meters USING btree (customer_id);


--
-- Name: idx_meters_device_eui; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_meters_device_eui ON public.meters USING btree (device_eui);


--
-- Name: idx_meters_online; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_meters_online ON public.meters USING btree (is_online);


--
-- Name: idx_meters_status; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_meters_status ON public.meters USING btree (status);


--
-- Name: idx_odoo_sync_next_attempt; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_odoo_sync_next_attempt ON public.odoo_sync_queue USING btree (next_attempt_at);


--
-- Name: idx_odoo_sync_status; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_odoo_sync_status ON public.odoo_sync_queue USING btree (status);


--
-- Name: idx_products_code; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_products_code ON public.products USING btree (product_code);


--
-- Name: idx_products_status; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_products_status ON public.products USING btree (status);


--
-- Name: idx_readings_eui; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_readings_eui ON public.meter_readings USING btree (device_eui);


--
-- Name: idx_readings_gateway; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_readings_gateway ON public.meter_readings USING btree (gateway_eui);


--
-- Name: idx_readings_meter_time; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_readings_meter_time ON public.meter_readings USING btree (meter_id, "timestamp" DESC);


--
-- Name: idx_readings_timestamp; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_readings_timestamp ON public.meter_readings USING btree ("timestamp" DESC);


--
-- Name: idx_tanker_customer; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_tanker_customer ON public.tanker_deliveries USING btree (customer_id);


--
-- Name: idx_tanker_scheduled; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_tanker_scheduled ON public.tanker_deliveries USING btree (scheduled_at DESC);


--
-- Name: idx_tanker_status; Type: INDEX; Schema: public; Owner: geedsan
--

CREATE INDEX idx_tanker_status ON public.tanker_deliveries USING btree (status);


--
-- Name: alarms alarms_acknowledged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.alarms
    ADD CONSTRAINT alarms_acknowledged_by_fkey FOREIGN KEY (acknowledged_by) REFERENCES public.users(id);


--
-- Name: alarms alarms_meter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.alarms
    ADD CONSTRAINT alarms_meter_id_fkey FOREIGN KEY (meter_id) REFERENCES public.meters(id) ON DELETE CASCADE;


--
-- Name: alarms alarms_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.alarms
    ADD CONSTRAINT alarms_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: billing_cycles billing_cycles_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.billing_cycles
    ADD CONSTRAINT billing_cycles_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: billing_cycles billing_cycles_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.billing_cycles
    ADD CONSTRAINT billing_cycles_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: billing_cycles billing_cycles_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.billing_cycles
    ADD CONSTRAINT billing_cycles_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE SET NULL;


--
-- Name: downlink_commands downlink_commands_meter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.downlink_commands
    ADD CONSTRAINT downlink_commands_meter_id_fkey FOREIGN KEY (meter_id) REFERENCES public.meters(id) ON DELETE SET NULL;


--
-- Name: downlink_commands downlink_commands_sent_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.downlink_commands
    ADD CONSTRAINT downlink_commands_sent_by_fkey FOREIGN KEY (sent_by) REFERENCES public.users(id);


--
-- Name: invoice_items invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_payments invoice_payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: invoice_payments invoice_payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: invoices invoices_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: meter_flow_history meter_flow_history_meter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.meter_flow_history
    ADD CONSTRAINT meter_flow_history_meter_id_fkey FOREIGN KEY (meter_id) REFERENCES public.meters(id) ON DELETE CASCADE;


--
-- Name: meter_readings meter_readings_meter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.meter_readings
    ADD CONSTRAINT meter_readings_meter_id_fkey FOREIGN KEY (meter_id) REFERENCES public.meters(id) ON DELETE CASCADE;


--
-- Name: meters meters_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.meters
    ADD CONSTRAINT meters_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: notification_settings notification_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_alarm_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_alarm_id_fkey FOREIGN KEY (alarm_id) REFERENCES public.alarms(id) ON DELETE SET NULL;


--
-- Name: reports reports_generated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_generated_by_fkey FOREIGN KEY (generated_by) REFERENCES public.users(id);


--
-- Name: tanker_deliveries tanker_deliveries_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.tanker_deliveries
    ADD CONSTRAINT tanker_deliveries_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: tanker_deliveries tanker_deliveries_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geedsan
--

ALTER TABLE ONLY public.tanker_deliveries
    ADD CONSTRAINT tanker_deliveries_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 4iYOjBzjMXbHtQQSfFfocvVUsfZhzNQMFvr7nPzPBxd8eqJrtsQ8lX4OoCDTvo9

